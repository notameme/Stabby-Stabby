using Terraria.ModLoader;

namespace StabbyStabby
{
	class StabbyStabby : Mod
	{
		public StabbyStabby()
		{
		}
	}
}
